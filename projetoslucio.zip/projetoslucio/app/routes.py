from flask import render_template, request, flash
import re
from app import app


app.secret_key = "ups"


@app.route("/")
@app.route("/entrada")
def entrada():
    return render_template('entrada.html')


@app.route("/express", methods=['POST', 'GET'])
def express():
    if request.method == "POST":

        codigo = request.form['expressao']
        expressao = request.form['expressoes regulares']

        if(expressao == 'data'):
            regex = r'^([1-9]|0[1-9]|[1,2][0-9]|3[0,1])/([1-9]|1[0,1,2])/\d{4}$'
        elif (expressao == 'numdec'):
            regex = r'^\d*[0-9](\.\d*[0-9])?$'
        elif (expressao == 'arq'):
            regex = r'^[a-zA-Z0-9-_\.]+\.(pdf|txt|doc|csv)$'
        elif (expressao == 'email'):
            regex = r'^([0-9a-zA-Z]+([_.-]?[0-9a-zA-Z]+)*@[0-9a-zA-Z]+[0-9,a-z,A-Z,.,-]*(.){1}[a-zA-Z]{2,4})+$'
        elif (expressao == 'cor'):
            regex = r'^#?([a-f]|[A-F]|[0-9]){3}(([a-f]|[A-F]|[0-9]){3})?$'
        elif (expressao == 'imagem'):
            regex = r'^[a-zA-Z0-9-_\.]+\.(jpg|gif|png)$'
        elif (expressao == 'ip'):
            regex = r'^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$'
        elif (expressao == 'hora'):
            regex = r'^([0-1][0-9]|[2][0-3])(:([0-5][0-9])){1,2}$'
        elif (expressao == 'codpostal'):
            regex = r'^\d{4}-\d{3}$'
        elif (expressao == 'tel'):
            regex = r'^(2|7|8|9)[0-9]{8}$'
        if re.match(regex, codigo):
            flash('Expressão aceite!', 'fine')
            return render_template('ExpReg.html')
        else:
            flash('Expressão rejeitada', 'ok')
            return render_template('ExpReg.html')
    else:
        return render_template('ExpReg.html')


@app.route("/finito", methods=['POST', 'GET'])
def finito():
    if request.method == "POST":
        comb = request.form['name']
        estadof = {"d"}
        aceitavel = {"0", "1"}
        estadoi = "a"
        automato = {
            ("a", "0"): "e", ("a", "1"): "b",
            ("b", "0"): "f", ("b", "1"): "c",
            ("c", "0"): "g", ("c", "1"): "d",
            ("d", "0"): "h", ("d", "1"): "b",
            ("e", "0"): "a", ("e", "1"): "f",
            ("f", "0"): "b", ("f", "1"): "g",
            ("g", "0"): "c", ("g", "1"): "h",
            ("h", "0"): "d", ("h", "1"): "f"}
        seq = comb

        estadoatual = estadoi

        for i in seq:
            if (i not in aceitavel):
                flash("erro, insira apenas 0's e 1's", 'error')
                return render_template("AutFin.html")

            estadoatual = automato[(estadoatual, i)]
        if(estadoatual not in estadof):
            flash('Sequencia não aceite', 'ok')
            return render_template("AutFin.html")
        else:
            flash("Sequencia aceite!",'fine')
            return render_template("AutFin.html")
    else:
        return render_template("AutFin.html")


@app.route("/pilha", methods=['POST', 'GET'])
def pilha():
    if request.method == "POST":
        sequencia = request.form['sequencia']
        aceitavel = {'0', '1'}
        end = '$'
        pilha=[]
        pilha.append(end)
        for caracter in sequencia:
            if caracter in aceitavel:
                if caracter == '0':
                    pilha.append(caracter)
                else:
                    if not pilha or pilha == ['$']:
                        flash("Sequência não aceite!",'ok')
                        return render_template('AutPilha.html')
                    else:
                        pilha.pop()
            else:
                flash("Caracteres incorretos!", 'error')
                return render_template('AutPilha.html')
        pilha.pop()
        if not pilha:
            flash("Sequência aceite!",'fine')
            return render_template('AutPilha.html')
        else:
            flash("Seequência não aceite!")
            return render_template('AutPilha.html')
    else:
        return render_template('AutPilha.html')
